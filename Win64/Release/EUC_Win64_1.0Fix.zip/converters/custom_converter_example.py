def DoConversion(from_value: float) -> float: # Must the function __must__ be named DoConversion.
    result = from_value * 3.6
    return result

# This example converts from Meters Per Second to Kilometers Per Hour.